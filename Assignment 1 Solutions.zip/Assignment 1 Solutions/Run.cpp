//BIG TOTAL[59]
//Total[24]
#include<iostream>
#include<ctime>
#include<string>
#include<fstream>
#include<cstring>
#include"Student.hpp"	
#include"SecondYearStudent.hpp"
using namespace std;


	void loadStudentInfo(string fileName, SecondYearStudent st[]);

	int main()
	{
		srand(time(NULL));
		SecondYearStudent st[4];  //(2)
				
		loadStudentInfo("Students.csv",st);  //(1)
		
		for(int x = 0; x < 4; x++) //(1)
		{
			
			st[x].calcFinalMark();  //(2)
			st[x].displayStudent(); //(2)
					
		}
		
	
		

		system("pause");
		return 0;
	}

	void loadStudentInfo(string fileName, SecondYearStudent st[])
	{
		string line = " ";
		ifstream input;  //(1)
		input.open(fileName.c_str()); //(1)
		
		int x = 0;
		int end = 0, num;
		double  assign[4], test[4];
		
		char name[30];
		char sur[30];
		string code[]={"DSO","TPG","ISY","SSF"}; //(1)
		while(getline(input,line)) //(1)
		{
			
			end = line.find(","); //(1)
			num = atoi(line.substr(0,end).c_str()); //(1)
			line = line.erase(0,end+1); //(1)

			
			end = line.find(",");
			strcpy_s(name,line.substr(0,end).c_str());
			line = line.erase(0,end+1);   //(1)

			
			end = line.find(",");
			strcpy_s(sur,line.substr(0,end).c_str());
			line = line.erase(0,end+1);   //(1)

			for(int i = 0; i < 4; i++) //(1)
			{
				end = line.find(",");//(1)
				assign[i] = atof(line.substr(0,end).c_str());
				line = line.erase(0,end+1);//(1)

				end = line.find(",");
				test[i] = atof(line.substr(0,end).c_str()); //(1)
				line = line.erase(0,end+1);//(1)
			}
		
			st[x].setStudent(num,name,sur,code,assign,test); //(1)
			x++;//(1)
		}
		
	}

