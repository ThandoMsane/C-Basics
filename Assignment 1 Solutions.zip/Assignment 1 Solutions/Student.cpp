//Total[6]
#include"Student.hpp"

Student::Student()
{
	name[0] = '\0'; //(1)
	surname[0] = '\0';   //(1)
	studentNumber = 0;
}
void Student::setStudent(int num, char n[], char s[])
{
	studentNumber = num; //(1)
	strcpy_s(name,n); //(1)
	strcpy_s(surname,s); //(1)
}
void Student::displayStudent()
{
	cout<<endl;
	cout<<studentNumber<<"\t"<<name<<"\t"<<surname<<endl; //(1)

}