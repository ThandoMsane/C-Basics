//Total[5]
#ifndef SecondYearStudent_hpp
#define SecondYearStudent_hpp
#include"Student.hpp"
#include<string>
#include<iostream>
#include<ctime>
#include<cmath>
	using namespace std;


const int MAX = 4;

class SecondYearStudent: public Student  //(2)
{

private:
	string code[MAX];
	double assignment[MAX];
	double test[MAX];
	double predicate[MAX];       
	double exam[MAX];
	double final[MAX];
	int testWeight;
	int assignWeight;
	void calcPredicate();    //(1)
	double determineStudentAvg();   //(1)
public:
	SecondYearStudent();
	void setStudent(int, char[], char[], string[],double[], double []);
//	void enterWeights();
	void displayStudent();                //(1)
	void calcFinalMark();


};

#endif