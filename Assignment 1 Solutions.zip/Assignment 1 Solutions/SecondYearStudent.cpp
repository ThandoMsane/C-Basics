//Total[22]

#include"SecondYearStudent.hpp"


SecondYearStudent::SecondYearStudent(): Student() //(1)
{
	for(int x = 0; x < MAX; ++x)
	{
		code[x] = " ";
		assignment[x] = 0.0;
		test[x] = 0.0;
		predicate[x] = 0.0;    //(2)
		exam[x] = 0.0;
		final[x] = 0.0;
	}
	testWeight = 60;  //(1)
	assignWeight = 40; //(1)

}
void SecondYearStudent::setStudent(int num, char n[], char s[],string c[], double a[], double t[])
{
	Student::setStudent(num,n,s); //(1)

	for(int x = 0; x < MAX; ++x)
	{
		code[x] = c[x];
		assignment[x] = a[x];  //(2)
		test[x] = t[x];
			
	}
}
//void SecondYearStudent::enterWeights()
//{
//	cout<<"Enter assignment weight:  ";
//	cin>>assignWeight;
//	cout<<"Enter test weight:  ";
//	cin>>testWeight;
//}
void SecondYearStudent::calcPredicate()
{
	for(int x = 0; x < MAX; x++)
	{
		predicate[x] = ((((assignment[x])/ 100)* assignWeight) + ((test[x] / 100) * testWeight)); //(3)
	}

}
void SecondYearStudent::calcFinalMark()
{
	
	calcPredicate(); //(1)
	for(int x = 0; x < MAX; x++)
	{
		exam[x] = rand() % 100;  //(2)
		final[x] = ceil((predicate[x] + exam[x]) / 2); //(1)
	}
	

}
double SecondYearStudent::determineStudentAvg()
{
	double sum = 0.0;
	for(int x = 0; x < MAX; x++) //(1)
	{
		sum += final[x]; //(1)
	}
	return sum / MAX; //(1)
}
void SecondYearStudent::displayStudent()
{
	Student::displayStudent(); //(1)
	
	for(int x = 0; x < MAX; x++)
	{
		cout<<"\t"<<code[x]<<"\t"<<predicate[x]<<"\t"<<exam[x]<<"\t"<<final[x]<<" % "<<endl; //(2)
	}
	cout<<"Average: "<<determineStudentAvg()<<endl; //(1)
}