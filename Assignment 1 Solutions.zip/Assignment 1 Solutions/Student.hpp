//Total[2]
#ifndef Student_hpp
#define Student_hpp
#include<string>
#include<iostream>
	using namespace std;


const int LEN = 30;
class Student
{
private:
	int studentNumber;
	char name[LEN];      //(1)
	char surname[LEN];
public:
	Student();
	void setStudent(int, char[], char[]);  //(1)
	void displayStudent();


};


#endif