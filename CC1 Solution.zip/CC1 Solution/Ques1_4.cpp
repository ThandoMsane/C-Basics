

#include <iostream.h>

#ifndef TWELVEMONTHACCOUNT
#define TWELVEMONTHACCOUNT

#include "Ques1_2.cpp"

class TwelveMonthAccount : public Account
  protected:
        static float interestRate;
  public:
        TwelveMonthAccount(int aN=0, char fN[]="", char s[]="",
                                       char aC='G', int rC=1, float b=0.0);
        static void setInterestRate(float iR);
        float determineAmountPayable();
};

float TwelveMonthAccount::interestRate = 0.0;

TwelveMonthAccount::TwelveMonthAccount
      (int aN, char fN[], char s[], char aC, int rC, float b)
                  : Account(aN, fN, s, aC, rC ,b)
{}

void TwelveMonthAccount::setInterestRate(float iR)
{
        interestRate = iR;
}

float TwelveMonthAccount::determineAmountPayable()
{
        float amntPayable = (balance + balance * interestRate/100)/12;
                                               //<== 2  Calculation
        if (amntPayable < 200.00)
                amntPayable = 200.00;

        return amntPayable;
}



#endif
//==========================================================================[2]