

#include <iostream.h>
#include "Ques1_1.cpp"
#include "Ques1_2.cpp"



int enterTransactions (Transaction *trPntr)  //<== 1 Header with pointer
{
        int accountNumber;
        int transactionType;
        float transactionAmount;
        int trans = 0;

        char answer = 'Y';

        do		//<== 1 Loop header & braces
		{
                  cout << "For transaction " << trans+1 << " enter:\n";
                  cout << "\tAccount number: ";
                  cin >> accountNumber;
                  cout << "\tTransaction type (1 for payment,2 for purchase): ";
                  cin >> transactionType;
                  cout << "\tTransaction amount: R";
                  cin >> transactionAmount;
                  (trPntr+trans)->setTransaction
                          (accountNumber, transactionType, transactionAmount);
                //<== 2 Proper set, using pointer arithmetic & array notation
                  cout << "Do you want to enter another transaction? "
                       << "(Y for yes, N for no) ";
		  cin >> answer;
		  trans++;
		}
        while (toupper(answer) == 'Y' && trans < 10);
                		//<== 2 Test condition
        return trans-1;
}		//<== 1 Return number of transactions

void enterAccount(Account *aCPntr)  //<== 1 Specify Account pointer
{
        int accountNumber;
        char firstName[MAXSIZE];
        char surname[MAXSIZE];
        char accountCategory;
        int repaymentCategory;
        float balance;

        cout << "For the account enter:\n";
	cout << "\tAccount number: " ;
	cin >> accountNumber;
        cout << "\tFirst name: ";
	cin >> firstName;
   	cout << "\tSurname: ";
	cin >> surname;
   	cout << "\tAccount Category:\n";
	cout << "\tEnter:\tP for Platinum\n";
      	cout << "\tEnter:\tG for Gold\n";
      	cout << "\tEnter:\tS for Silver\n";
      	cout << "\tEnter:\tB for Bronze\n\t";
	cin >> accountCategory;
        cout << "Repayment Category (1, 2 or 3): ";
        cin >> repaymentCategory;
   	cout << "Current Balance: ";
	cin >> balance;

	aCPntr->setAccount(accountNumber,firstName,surname,accountCategory,
               repaymentCategory,balance);  //<== 1 Set
}

void displayAccount(Account *aCPntr)
{
	int accountNumber;
        char firstName[MAXSIZE];
        char surname[MAXSIZE];
        string accountCategory;
        float amntPayable;

	aCPntr->getAccount(accountNumber, firstName, surname, accountCategory);
			//<== 1 Call accessor method

	amntPayable = aCPntr->determineAmountPayable();   //<== 1 Call

	cout << "Amount due for " << accountCategory;

	cout << " account " << accountNumber << " - "
             << firstName << ' '<< surname << " is R" << amntPayable << endl;
				//<== 1 Display

}
//=======================================================================[12]
