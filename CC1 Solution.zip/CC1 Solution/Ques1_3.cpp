

#include <iostream.h>

#ifndef SIXMONTHACCOUNT
#define SIXMONTHACCOUNT

#include "Ques1_2.cpp"

class SixMonthAccount : public Account    //<== 1 Inheritance
{
  protected:
        static float clubFee;    //<== 1 Static data member
  public:
        SixMonthAccount(int aN=0, char fN[]="",
                          char s[]="", char aC='P', int rC=1, float b=0.0);
        static void setClubFee(float cF);   //<== 1 Static method
        float determineAmountPayable();  //<== 1 Override method
};

float Account::clubFee = 0.0;   //<== 1 Initialize at global scope

SixMonthAccount::SixMonthAccount
       (int aN, char fN[], char s[], char aC, int rC, float b)
                  : Account(aN, fN, s, aC, rC, b)
{}                               //<== 1 Call base class constructor

void SixMonthAccount::setClubFee(float cF)  //<== 1 Not re-state static
{
        clubFee = cF;
}

float SixMonthAccount::determineAmountPayable()
{
        float amntPayable = balance / 6;    //<== 1 Correct calculation

        if (amntPayable < 100.00)
                amntPayable = 100.00;

        amntPayable += clubFee;   //<== 1 Increment with club fee
        return amntPayable;
}

#endif
//==========================================================================[9]