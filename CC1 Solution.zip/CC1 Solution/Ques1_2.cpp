

#include <iostream.h>

#ifndef ACCOUNT
#define ACCOUNT

#include "Ques1_1.cpp"

#include <fstream.h>

const int MAXSIZE = 30;
const int NUMACCCATS = 4;      //<== 1 Use of constants for array sizes
const int NUMREPCATS = 3;

class Account
{
  protected:     //<== 1 Access specifier
        int accountNumber;
        char firstName[MAXSIZE];	//<== 1 Correct c-string declarations
        char surname[MAXSIZE];
        char accountCategory;
        int repaymentCategory;
        static char accCategories[NUMACCCATS];  //<== 1 Static array decls
        static string accCatDesc[NUMACCCATS];
        static float creditLimit[NUMACCCATS][NUMREPCATS];
                                      //<== 2 static 2-dim array decl
        float balance;
  public:
        Account(int aN=0, char fN[]="", char s[]="",
                      char aC=1, int rC = 1, float b=0.0);
                                             //<== 1 Default arguments
        void setAccount(int aN, char fN[], char s[],
                                        char aC, int rC, float b);
        static void readAndSetCreditLimits(string fileName);
                                                //<== 1 Static method
        float calculateCreditLimit();
        void operator+(Transaction &tr);      //<== 1 Operator method prototype
        virtual float determineAmountPayable(){return 0;};
                                      //<== 2 Virtual method & implementation
        float getBalance();
        void getAccount(int &aN, char fN[],char s[], string &aC);
};
       //<== 3 Initilization at global scope with appropriate values
char Account::accCategories[NUMACCCATS]={'P', 'G', 'S', 'B'};
string Account::accCatDesc[NUMACCCATS]={"Platinum", "Gold", "Siver", "Bronze"};
float Account::creditLimit[NUMACCCATS][NUMREPCATS]={0.0};

Account::Account(int aN, char fN[], char s[], char aC, int rC, float b)
{                             //<== 1 Not re-stating default arguments
        accountNumber = aN;
        strcpy(firstName, fN);
        strcpy(surname, s);   //<== 1 Use of strcpy
        accountCategory = aC;
        repaymentCategory = rC;
        balance = b;
}

void Account::setAccount(int aN, char fN[], char s[], char aC, int rC, float b)
{
        accountNumber = aN;
        strcpy(firstName, fN);
        strcpy(surname, s);
        accountCategory = aC;	//<== 1 Complete method
        repaymentCategory = rC;
        balance = b;
}

void Account::readAndSetCreditLimits(string fileName)
{
       ifstream creditLimitIn (fileName.c_str());
                         //<== 2 Convert to c-string & Create file object
       if (!creditLimitIn)    //<== 1 Check could be opened
       {
          string message;
          message = "File " + fileName + " could not be opened";
          throw (message);              //<== 2 Error handling
       }

       string strLine;     //<== 1 Declaration of variables needed
       int line = 0;
       int mPos;
       while (getline(creditLimitIn, strLine))    //<== 2 Read and Repeat
       {
          for (int col=0; col < NUMREPCATS; col++)  //<== 1 Loop
          {
                mPos = strLine.find(",");          //<== 1 Find comma
                creditLimit[line][col] = atof(strLine.substr(0, mPos).c_str());
                                    //<== 1 Convert to float & place in array
                strLine = strLine.erase(0, (mPos + 1));
          }
          line++;    //<== 1 Increment the number of lines
       }
}





float Account::calculateCreditLimit()
{
        int row, col;
        switch(accountCategory)        //<== 2 Determine row reference
        {
           case 'P' : row = 0; break;
           case 'G' : row = 1; break;
           case 'S' : row = 2; break;
           case 'B' : row = 3; break;
           default  : row = 0;
        }
        col = repaymentCategory-1;    //<== 1 Determine col reference

        return creditLimit[row][col];  //<== 1 Table look-up
}

void Account::operator+(Transaction &tr)	//<== 1 void return type
{						//      & passing object
        float transAmnt;
        if (accountNumber == tr.getAccountNumber())  //<== 2 Call & test
        {
            transAmnt = tr.getTransactionAmnt();
            if (transAmnt <= 0)	    //<== 1 Correct test for purchase / payment
            {
                balance += transAmnt;	//<== 1 Proper statement executed
            }
            else
                if ((balance + transAmnt) > calculateCreditLimit())
                {				//<== 1 Test for enough credit
                   cout << "Credit limit exceeded - transaction not applied\n";
                }
                else
                {
                    balance += transAmnt;	//<== 1 Apply transaction
                }
         }
         else
         {
            cout << "Cannot apply transaction. Account numbers do not match\n";
         }				//<== 1 Display

}

float Account::getBalance()
{
        return balance;     //<== 1 Accessor method
}

void Account::getAccount(int &aN, char fN[], char s[], string &aC)
{			//<== 1 Use two reference parameters & c-strings
        aN = accountNumber;
        strcpy(fN, firstName);   //<== 1 Copy values to parameters
        strcpy(s, surname);
        for (int accCat=0; accCat < NUMACCCATS; accCat++) //<== 1 Array look-up
        {
                if(accountCategory == accCategories[accCat])
                {
                   aC = accCatDesc[accCat];
                   break;
                }
        }
}

#endif
//==========================================================================[45]