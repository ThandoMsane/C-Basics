

#include <iostream.h>
#include <conio.h>

#include "Ques1_3.cpp"
#include "Ques1_4.cpp"
#include "Ques1_5.cpp"

const int MAXTRANS = 10;

void main()
{
        try      //<== 1 Try block
        {
                Account::readAndSetCreditLimits("creditlimits.csv");
        }                  //<== 2 Calling static method
        catch (string mess)    //<== 2 Catch Block and error handling
        {
                cout << mess << endl;
                getch();
                exit(1);
        }
        
	SixMonthAccount six;

	Transaction *transPntr = new Transaction[MAXTRANS];
                             //<== 1 Dynamically create Transaction array

	enterAccount(&six);	//<== 2 Call, sending addr
        SixMonthAccount::setClubFee(12.50);  //<== 1 Set club fee

	int numTrans;
        numTrans = enterTransactions(transPntr); //<== 1 Call sending pointer
        for (int trn=0; trn < numTrans; trn++)
        {
            six + *(transPntr+trn); //<== 3 Operator call with array arithmetic
        }

        displayAccount(&six);	//<== 1 Call

        Account *accPntr;   //<== 1 Declare base class pointer
        float amntPayable;

        accPntr = &six;   //<== 3 Illustrate polymorphism
        amntPayable = accPntr->determineAmountPayable();
        cout << "The amount payable on the six month account is: R"
             << amntPayable << endl;

                        //<== 2 Illustrate polymorphism
        TwelveMonthAccount *twelvePntr = new TwelveMonthAccount
                         (1234, "Maria", "Meintjes", 'G', 1, 1200.00);
        TwelveMonthAccount::setInterestRate(15.50);  //<== 1 Set interest rate
        accPntr = twelvePntr;
        amntPayable = accPntr->determineAmountPayable();

        cout << "The amount payable on the twelve month account is: R"
             << amntPayable << endl;

	getch();
}



//==========================================================================[21]







